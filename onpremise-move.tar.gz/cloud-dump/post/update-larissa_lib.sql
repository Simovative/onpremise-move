UPDATE `cms_domains`
SET `larissa_lib` = '/srv/a5_source/httpdocs/lib/';
